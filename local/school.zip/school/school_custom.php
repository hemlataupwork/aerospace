<?php
require_once "../../config.php";
require_once $CFG->libdir . "/tablelib.php";
require_once "classes/table/school_table.php"; // Adjust the path as per your file structure
global $page, $DB, $OUTPUT, $PAGE;

$page = optional_param('page', 0, PARAM_INT);
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->requires->js(new \moodle_url('https://cdn.datatables.net/v/bs4/dt-1.10.20/af-2.3.4/b-1.6.1/b-colvis-1.6.1/b-html5-1.6.1/b-print-1.6.1/cr-1.5.2/fc-3.3.0/fh-3.1.6/kt-2.5.1/r-2.2.3/rg-1.1.1/rr-1.2.6/sc-2.0.1/sp-1.0.1/sl-1.3.1/datatables.min.js'), true);
$PAGE->requires->css(new \moodle_url('https://cdn.datatables.net/v/bs4/dt-1.10.20/af-2.3.4/b-1.6.1/b-colvis-1.6.1/b-html5-1.6.1/b-print-1.6.1/cr-1.5.2/fc-3.3.0/fh-3.1.6/kt-2.5.1/r-2.2.3/rg-1.1.1/rr-1.2.6/sc-2.0.1/sp-1.0.1/sl-1.3.1/datatables.min.css'));
echo '<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>';


$download = optional_param('download', '', PARAM_ALPHA);

$table = new school_class_table('uniqueid');
$table->is_downloading($download, 'test', 'testing123');

if (!$table->is_downloading()) {
    $PAGE->set_pagelayout('standard');
    $PAGE->set_title('School');
    $PAGE->set_heading('School Table');
    $PAGE->navbar->add('School Table', new moodle_url('/school_custom.php')); // Check if the correct URL should be used
    echo $OUTPUT->header();
    echo '<div class="action-button">';
    echo html_writer::start_div('action-button-container');
    echo html_writer::link(new moodle_url('/local/school/school_form.php'), 'Add New School', array('class' => 'btn btn-primary'));
    echo html_writer::end_div();
    echo '</div>';

    $fields = "sc.id, sc.school_sortname, sc.school_name AS school_name, sc.school_address AS address, sc.id AS schoolid, sc.status";
    $from =  "{school} sc ";
    $where = "'1==1'";

    $table->set_sql($fields, $from, $where);
    $table->define_baseurl("$CFG->wwwroot/local/school/school_custom.php?page=$page");

    $table->out($perpage, true);

    echo $OUTPUT->footer();
}
?>
<script>
    $(document).ready(function() {
        $('.region-main').find('table').DataTable();
        const data = document.querySelectorAll('a')
        data.forEach((e) => {
            if (e.innerText.includes("Action")) {
                e.href = ''
            }

        })
    });
</script>