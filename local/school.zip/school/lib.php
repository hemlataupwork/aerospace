    <?php

function local_school_extend_navigation(global_navigation $navigation) {
    global $CFG, $PAGE;
  
    $icon = new pix_icon('key', '', 'local_school', array('class' => 'icon pluginicon', 'style' => 'width: 22px; height: 30px; object-fit: contain;'));

        $previewnode = $PAGE->navigation->add(
            get_string('school','local_school'),
            new moodle_url($CFG->wwwroot . '/local/school/school_custom.php'),
            navigation_node::TYPE_CONTAINER
            
        );
        $thingnode = $previewnode->add(
            get_string('all_cohort','local_school'),
            new moodle_url($CFG->wwwroot . '/cohort/index.php?contextid=1&showall=1')
        );
        $thingnode = $previewnode->add(
            get_string('category','local_school'),
            new moodle_url($CFG->wwwroot . '/course/management.php') 
        );
        $thingnode = $previewnode->add(
            get_string('add_student','local_school'),
            new moodle_url($CFG->wwwroot . '/local/school/cohort_form1.php')
        );
        // $thingnode->make_active();
}
