<?php

$string['pluginname'] = 'School';
$string['school_name'] = 'School Name';
$string['school_sortname'] = 'Sortname';
$string['school_address'] = 'School Address';
$string['principal_detail'] = 'Principal Name';
$string['principal_email'] = 'Principal Email';
$string['principal_contact'] = 'Principal Contact';
$string['coordinator_detail'] = 'Coordinator name';
$string['coordinator_email'] = 'Coordinator Email';
$string['coordinator_contact'] = 'Coordinator Contact';
$string['syllabus'] = 'Syllabus';
$string['aerobay_fees'] = 'Aerobay Fees';
$string['profile'] = 'School Profile';
$string['selectcohort'] = 'Select Cohort';
$string['selectuser'] = 'Select Users';
$string['cohort'] = 'Add User into Cohort';
$string['deleteconfirm'] = 'Are you sure want to delete school';
$string['school'] = 'School Management';
$string['category'] = 'Manage Course and Activity';
$string['all_cohort'] = 'Enroll user in school';
$string['add_student'] = 'Add Student';
$string['savechanges'] = 'Savechanges';
$string['savechanges1'] = 'Add School';
$string['schoolsuccess'] = 'School created Successfully';
?>
