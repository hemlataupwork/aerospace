<?php
require_once('../../config.php');
require_once($CFG->dirroot . '/user/lib.php');
require_once($CFG->dirroot . '/cohort/lib.php');
require_once('classes/form/school_form.php');

global $PAGE, $CFG;

require_login();

$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('standard');
$PAGE->set_title('School Registration');
$PAGE->set_heading('School Registration Form');

$mform = new school_form();

if ($mform->is_cancelled()) {

    redirect("$CFG->wwwroot/my/");

} elseif ($data = $mform->get_data()) {
  
    $DB->insert_record('school', $data);

    // Create cohort
    $cohort = new stdClass();
    $cohort->contextid = context_system::instance()->id;
    $cohort->name = $data->school_sortname;
    $cohort->idnumber = 'testid';
    $cohort->description = 'NOTHING';
    $cohort->descriptionformat = FORMAT_HTML;
    $cohortid = cohort_add_cohort($cohort);

    // Create category
    $category = new stdClass();
    $category->name = $data->school_sortname;
    $category->description = 'This is the main category';
    $category->parent = 0;
    $categoryid = core_course_category::create($category);

    redirect("$CFG->wwwroot/local/school/school_custom.php", get_string('schoolsuccess', 'local_school'), 2);
} else {
    echo $OUTPUT->header();
    $mform->display();
    echo $OUTPUT->footer();
}
