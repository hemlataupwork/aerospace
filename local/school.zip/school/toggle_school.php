<?php
require_once('../../config.php');

$id = required_param('id', PARAM_INT);

// Fetch current status
$school = $DB->get_record('school', array('id' => $id), '*', MUST_EXIST);
// Toggle the enabled status
$new_status = $school->status ? 0 : 1;



    $school = new stdClass();
    $school->id = $id;
    $school->status = $new_status;
    $school_record = $DB->get_record('school', ['id' => $id]);

    $DB->update_record('school', $school);

redirect($CFG->wwwroot . '/local/school/school_custom.php');
