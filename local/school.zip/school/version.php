<?php
defined('MOODLE_INTERNAL') || die();
$plugin ->component = 'local_school';
$plugin->version = 2024011700;
$plugin->requires = 2022011700;
?>