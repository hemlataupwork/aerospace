<?php

class school_class_table extends table_sql
{


    function __construct($uniqueid)
    {
        parent::__construct($uniqueid);

        $columns = array('school_name', 'schoolid', 'edit');
        $this->define_columns($columns);

        $headers = array('School Name', 'School ID', 'Action');
        $this->define_headers($headers);
    }

    function col_timecreated($values) {
       
        $times=date("d-m-Y", $values->timecreated);
        return $times;  
    
}
    function col_status($values) {
       
         
    
}

    function col_edit($values)
    {
        global $CFG;
        $button_html = "<a href='$CFG->wwwroot/local/school/edit_school.php?id=$values->id' class='btn btn-primary mr-2'><i class='fa fa-pencil'></i></a>
        <a href='$CFG->wwwroot/local/school/delete_school.php?id=$values->id&school_sortname=$values->school_sortname' class='btn btn-primary
         mr-2'><i class='fa fa-trash '></i></a>
        <a href='$CFG->wwwroot/local/school/school_profile.php' class='btn btn-primary mr-2'><i class='fa fa-sign-in'></i></a>
        <a href='$CFG->wwwroot/local/school/toggle_school.php?id=$values->id'class='btn btn-primary mr-2'><i class='fa fa-eye '></i></a>";


        return $button_html;
    }
}
