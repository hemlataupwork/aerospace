<?php

defined('MOODLE_INTERNAL') || die();

require_once("$CFG->libdir/formslib.php");

class edit_school_form extends moodleform
{
 public $schoolid;

    public function __construct($schoolid)
    {
        $this->schoolid = $schoolid;
        parent::__construct();
    }
    // Add elements to form.
    public function definition()
    {

        $mform = $this->_form; // Don't forget the underscore!

        $mform->addElement('hidden', 'schoolid',$this->schoolid);
        // Add elements to your form.
        $mform->addElement('text', 'school_name', get_string('school_name','local_school'));
        $mform->addElement('text', 'school_sortname', get_string('school_sortname','local_school'));
        $mform->addElement('text', 'school_address', get_string('school_address','local_school'));
        $mform->addElement('text', 'principal_detail', get_string('principal_detail','local_school'));
        $mform->addElement('text', 'principal_email', get_string('principal_email','local_school'));
        $mform->addElement('text', 'principal_contact', get_string('principal_contact','local_school'));
        $mform->addElement('text', 'coordinator_detail', get_string('coordinator_detail','local_school'));
        $mform->addElement('text', 'coordinator_email', get_string('coordinator_email','local_school'));
        $mform->addElement('text', 'coordinator_contact', get_string('coordinator_contact','local_school'));
        $mform->addElement('text', 'syllabus', get_string('syllabus','local_school'));
        $mform->addElement('text', 'aerobay_fees', get_string('aerobay_fees','local_school'));
       

        // Set type of element.
        $mform->setType('text', PARAM_NOTAGS);

        // Default value.
        $mform->setDefault('school_name', '');
        $mform->setDefault('school_sortname', '');
        $mform->setDefault('school_address', '');
        $mform->setDefault('principal_detail', '');
        $mform->setDefault('principal_email', '');
        $mform->setDefault('principal_contact', '');
        $mform->setDefault('coordinator_detail', '');
        $mform->setDefault('coordinator_email', '');
        $mform->setDefault('coordinator_contact', '');
        $mform->setDefault('syllabus', '');

        // Apply validation rules.
        $mform->addRule('school_name', get_string('required'), 'required', null, 'client');
        $mform->addRule('school_sortname', get_string('required'), 'required', null, 'client');
        $mform->addRule('school_address', get_string('required'), 'required', null, 'client');
        $mform->addRule('principal_detail', get_string('required'), 'required', null, 'client');
        $mform->addRule('principal_email', get_string('required'), 'required', null, 'client');
        $mform->addRule('principal_contact', get_string('required'), 'required', null, 'client');
        $mform->addRule('coordinator_detail', get_string('required'), 'required', null, 'client');
        $mform->addRule('coordinator_email', get_string('required'), 'required', null, 'client');
        $mform->addRule('coordinator_contact', get_string('required'), 'required', null, 'client');
        $mform->addRule('syllabus', get_string('required'), 'required', null, 'client');
        $mform->addRule('aerobay_fees', get_string('required'), 'required', null, 'client');
        

        $searchareas = \core_search\manager::get_search_areas_list(true);
        $areanames = array();
        foreach ($searchareas as $areaid => $searcharea) {
            $areanames[$areaid] = $searcharea->get_visible_name();
        }
        
        $buttonarray = array();
        $buttonarray[] = $mform->createElement('submit', 'submitbutton', get_string('savechanges'));

        $buttonarray[] = $mform->createElement('cancel');
        $mform->addGroup($buttonarray, 'buttonar', '', ' ', false);
    }


    function validation($data, $files)
    {
        $errors = [];
        if (empty(trim($data['school_name']))) {
            $errors['school_name'] = get_string('required');
        }
        if (empty(trim($data['school_sortname']))) {
            $errors['school_sortname'] = get_string('required');
        }
        if (empty(trim($data['school_address']))) {
            $errors['school_address'] = get_string('required');
        }
        if (empty(trim($data['principal_detail']))) {
            $errors['principal_detail'] = get_string('required');
        }
        if (empty(trim($data['principal_email']))) {
            $errors['principal_email'] = get_string('required');
        }
        if (empty(trim($data['principal_contact']))) {
            $errors['principal_contact'] = get_string('required');
        }
        if (empty(trim($data['coordinator_detail']))) {
            $errors['coordinator_detail'] = get_string('required');
        }
        if (empty(trim($data['coordinator_email']))) {
            $errors['coordinator_email'] = get_string('required');
        }
        if (empty(trim($data['coordinator_contact']))) {
            $errors['coordinator_contact'] = get_string('required');
        }
        if (empty(trim($data['syllabus']))) {
            $errors['syllabus'] = get_string('required');
        }
        if (empty(trim($data['aerobay_fees']))) {
            $errors['aerobay_fees'] = get_string('required');
        }
        return $errors;
    }
}
