<?php

defined('MOODLE_INTERNAL') || die();

require_once("$CFG->libdir/formslib.php");

class school_form extends moodleform {
    // Add elements to form.
    public function definition() {
        $mform = $this->_form; // Don't forget the underscore!

        // Add elements to your form.
        $mform->addElement('hidden', 'schoolid');
        $mform->setType('schoolid', PARAM_INT);

        $mform->addElement('text', 'school_name', get_string('school_name', 'local_school'));
        $mform->setType('school_name', PARAM_NOTAGS);

        $mform->addElement('text', 'school_sortname', get_string('school_sortname', 'local_school'));
        $mform->setType('school_sortname', PARAM_NOTAGS);

        $mform->addElement('text', 'school_address', get_string('school_address', 'local_school'));
        $mform->setType('school_address', PARAM_NOTAGS);

        $mform->addElement('text', 'principal_detail', get_string('principal_detail', 'local_school'));
        $mform->setType('principal_detail', PARAM_NOTAGS);

        $mform->addElement('text', 'principal_email', get_string('principal_email', 'local_school'));
        $mform->setType('principal_email', PARAM_NOTAGS);

        $mform->addElement('text', 'principal_contact', get_string('principal_contact', 'local_school'));
        $mform->setType('principal_contact', PARAM_NOTAGS);

        $mform->addElement('text', 'coordinator_detail', get_string('coordinator_detail', 'local_school'));
        $mform->setType('coordinator_detail', PARAM_NOTAGS);

        $mform->addElement('text', 'coordinator_email', get_string('coordinator_email', 'local_school'));
        $mform->setType('coordinator_email', PARAM_NOTAGS);

        $mform->addElement('text', 'coordinator_contact', get_string('coordinator_contact', 'local_school'));
        $mform->setType('coordinator_contact', PARAM_NOTAGS);

        $mform->addElement('text', 'syllabus', get_string('syllabus', 'local_school'));
        $mform->setType('syllabus', PARAM_NOTAGS);

        $mform->addElement('text', 'aerobay_fees', get_string('aerobay_fees', 'local_school'));
        $mform->setType('aerobay_fees', PARAM_INT);

        // Default value.
        $mform->setDefault('school_name', '');
        $mform->setDefault('school_sortname', '');
        $mform->setDefault('school_address', '');
        $mform->setDefault('principal_detail', '');
        $mform->setDefault('principal_email', '');
        $mform->setDefault('principal_contact', '');
        $mform->setDefault('coordinator_detail', '');
        $mform->setDefault('coordinator_email', '');
        $mform->setDefault('coordinator_contact', '');
        $mform->setDefault('syllabus', '');
        $mform->setDefault('aerobay_fees', '');

        // Apply validation rules.
        $mform->addRule('school_name', get_string('required'), 'required', null, 'client');
        $mform->addRule('school_sortname', get_string('required'), 'required', null, 'client');
        $mform->addRule('school_address', get_string('required'), 'required', null, 'client');
        $mform->addRule('principal_detail', get_string('required'), 'required', null, 'client');
        $mform->addRule('principal_email', get_string('required'), 'required', null, 'client');
        $mform->addRule('principal_contact', get_string('required'), 'required', null, 'client');
        $mform->addRule('coordinator_detail', get_string('required'), 'required', null, 'client');
        $mform->addRule('coordinator_email', get_string('required'), 'required', null, 'client');
        $mform->addRule('coordinator_contact', get_string('required'), 'required', null, 'client');
        $mform->addRule('syllabus', get_string('required'), 'required', null, 'client');
        $mform->addRule('aerobay_fees', get_string('required'), 'required', null, 'client');
        $mform->addRule('aerobay_fees', null, 'numeric', null, 'client'); // Add numeric validation rule.

        $this->add_action_buttons(true, get_string('savechanges1', 'local_school'));
    }

    function validation($data, $files) {
        $errors = [];
        if (empty(trim($data['school_name']))) {
            $errors['school_name'] = get_string('required');
        }
        if (empty(trim($data['school_sortname']))) {
            $errors['school_sortname'] = get_string('required');
        }
        if (empty(trim($data['school_address']))) {
            $errors['school_address'] = get_string('required');
        }
        if (empty(trim($data['principal_detail']))) {
            $errors['principal_detail'] = get_string('required');
        }
        if (empty(trim($data['principal_email']))) {
            $errors['principal_email'] = get_string('required');
        }
        if (empty(trim($data['principal_contact']))) {
            $errors['principal_contact'] = get_string('required');
        }
        if (empty(trim($data['coordinator_detail']))) {
            $errors['coordinator_detail'] = get_string('required');
        }
        if (empty(trim($data['coordinator_email']))) {
            $errors['coordinator_email'] = get_string('required');
        }
        if (empty(trim($data['coordinator_contact']))) {
            $errors['coordinator_contact'] = get_string('required');
        }
        if (empty(trim($data['syllabus']))) {
            $errors['syllabus'] = get_string('required');
        }
        if (empty(trim($data['aerobay_fees'])) || !is_numeric($data['aerobay_fees'])) {
            $errors['aerobay_fees'] = get_string('required');
        }
        return $errors;
    }
}
