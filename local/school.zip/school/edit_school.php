<?php
require_once('../../config.php');
require_once($CFG->dirroot . '/user/lib.php');
require_once('classes/form/edit_school_form.php');

global $PAGE, $CFG, $DB;

require_login();

$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('standard');
$PAGE->set_title('School Registration');
$PAGE->set_heading('School Update Form');
$schoolid = optional_param('id', 0, PARAM_INT);

$school_record = $DB->get_record('school', ['id' => $schoolid]);
$school = new stdClass();
$school->school_name = $school_record->school_name;
$school->school_sortname = $school_record->school_sortname;
$school->school_address = $school_record->school_address;
$school->principal_detail = $school_record->principal_detail;
$school->principal_email = $school_record->principal_email;
$school->principal_contact = $school_record->principal_contact;
$school->coordinator_detail = $school_record->coordinator_detail;
$school->coordinator_email = $school_record->coordinator_email;
$school->coordinator_contact = $school_record->coordinator_contact;
$school->syllabus = $school_record->syllabus;
$school->aerobay_fees = $school_record->aerobay_fees;

$form = new edit_school_form($schoolid);

$form->set_data($school);

if ($form->is_cancelled()) {
    redirect("$CFG->wwwroot/my/");
} elseif ($data = $form->get_data()) {
    $school = new stdClass();
    $school->id = $data->schoolid;
    $school->school_name = $data->school_name;
    $school->school_sortname = $data->school_sortname;
    $school->school_address = $data->school_address;
    $school->principal_detail = $data->principal_detail;
    $school->principal_email = $data->principal_email;
    $school->principal_contact = $data->principal_contact;
    $school->coordinator_detail = $data->coordinator_detail;
    $school->coordinator_email = $data->coordinator_email;
    $school->coordinator_contact = $data->coordinator_contact;
    $school->syllabus = $data->syllabus;
    $school->aerobay_fees = $data->aerobay_fees;
    $school_record = $DB->get_record('school', ['id' => $data->schoolid]);

    $DB->update_record('school', $school);

    $cohort = $DB->get_record('cohort', ['name' => $school_record->school_sortname]);
    $objcohort = new stdClass();
    $objcohort->id = $cohort->id;
    $objcohort->name = $data->school_sortname;

    $DB->update_record('cohort', $objcohort);


    $category = $DB->get_record('course_categories', ['name' => $school_record->school_sortname]);
    $objcategory = new stdClass();
    $objcategory->id = $category->id;
    $objcategory->name = $data->school_sortname;
    $DB->update_record('course_categories', $objcategory);


    redirect("$CFG->wwwroot/local/school/school_custom.php");
} else {

    echo $OUTPUT->header();
    $form->display();
    echo $OUTPUT->footer();
}
