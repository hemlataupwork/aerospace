<?php

$observers = [
    [
        'eventname' => '\core\event\user_created',
        'callback' => '\local_trainer\send_emailobserver::user_created',
    ],
];

