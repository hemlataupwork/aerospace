<?php
$string['pluginname'] = 'Trainer';
$string['firstname'] = 'First Name';
$string['lastname'] = 'Last Name';
$string['dob'] = 'Date of Birth';
$string['bloodgroup'] = 'Blood Group';
$string['email'] = 'E-mail ID';
$string['contactnumber'] = 'Contact Number';
$string['permanentaddress'] = 'permanent Address';
$string['currentaddress'] = 'Current Address';
$string['alternativeaddress'] = 'Alternative Address';
$string['experience'] = 'Experience';
$string['ctc'] = 'Current CTC';
$string['dateofjoining'] = 'Date of joining';
$string['designation'] = 'Department';
$string['savechanges'] = 'Save';
$string['username'] = 'Username';
$string['password'] = 'Password';
$string['deleteconfirm'] = 'Are you sure want to delete data';
$string['trainersuccess'] = 'Trainer Created Successfully!';
$string['state'] = 'State';
$string['deletesuccess'] = 'Trainer data deleted successfully';
$string['updatesuccess'] = 'Trainer data updated successfully';
$string['userexists'] = 'User already exist';


